package dev.mrk.meshingress.api.result.structured;

public final class StructuredContentSchemas {
    private StructuredContentSchemas() {}

    public static final String TEXT_PLAIN_V1 = "meshingress.text.plain.v1";
    public static final String TEXT_MARKDOWN_V1 = "meshingress.text.markdown.v1";
    public static final String TEXT_HTML_V1 = "meshingress.text.html.v1";

    public static final String MEDIA_VIDEO_V1 = "meshingress.media.video.v1";
    public static final String MEDIA_IMAGE_V1 = "meshingress.media.image.v1";
    public static final String MEDIA_AUDIO_V1 = "meshingress.media.audio.v1";
    public static final String MEDIA_GALLERY_V1 = "meshingress.media.gallery.v1";
    public static final String MEDIA_PLAYLIST_V1 = "meshingress.media.playlist.v1";
    public static final String MEDIA_TRANSCRIPT_V1 = "meshingress.media.transcript.v1";

    public static final String FILE_GENERIC_V1 = "meshingress.file.generic.v1";
    public static final String FILE_ARCHIVE_V1 = "meshingress.file.archive.v1";
    public static final String FILE_DIRECTORY_V1 = "meshingress.file.directory.v1";
    public static final String FILE_MANIFEST_V1 = "meshingress.file.manifest.v1";

    public static final String WEB_PAGE_V1 = "meshingress.web.page.v1";
    public static final String WEB_HTML_V1 = "meshingress.web.html.v1";
    public static final String WEB_LINK_V1 = "meshingress.web.link.v1";
    public static final String WEB_SCREENSHOT_V1 = "meshingress.web.screenshot.v1";
    public static final String WEB_ELEMENT_V1 = "meshingress.web.element.v1";

    public static final String PROCESS_EXECUTION_V1 = "meshingress.process.execution.v1";
    public static final String PROCESS_DIAGNOSTIC_V1 = "meshingress.process.diagnostic.v1";

    public static final String DATA_RECORD_V1 = "meshingress.data.record.v1";
    public static final String DATA_RECORDS_V1 = "meshingress.data.records.v1";
    public static final String DATA_TABLE_V1 = "meshingress.data.table.v1";
    public static final String DATA_TREE_V1 = "meshingress.data.tree.v1";
    public static final String DATA_TIMELINE_V1 = "meshingress.data.timeline.v1";

    public static final String SEARCH_RESULTS_V1 = "meshingress.search.results.v1";
    public static final String RETRIEVAL_CONTEXT_V1 = "meshingress.retrieval.context.v1";

    public static final String MESSAGE_NOTIFICATION_V1 = "meshingress.message.notification.v1";

    public static final String IDENTITY_USER_V1 = "meshingress.identity.user.v1";
    public static final String IDENTITY_ACCOUNT_V1 = "meshingress.identity.account.v1";

    public static final String TOOL_DESCRIPTOR_V1 = "meshingress.tool.descriptor.v1";
    public static final String TOOL_LIST_V1 = "meshingress.tool.list.v1";
    public static final String RUNTIME_HEALTH_V1 = "meshingress.runtime.health.v1";

    public static final String SECURITY_DECISION_V1 = "meshingress.security.decision.v1";
    public static final String AUDIT_RECORD_V1 = "meshingress.audit.record.v1";

    public static final String CALENDAR_EVENT_V1 = "meshingress.calendar.event.v1";
    public static final String CALENDAR_EVENTS_V1 = "meshingress.calendar.events.v1";

    public static final String NETWORK_HTTP_RESPONSE_V1 = "meshingress.network.http.response.v1";
}
