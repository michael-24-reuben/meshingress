package dev.mrk.meshingress.api.result.structured.data;

public record TableColumn(
        String key,
        String label,
        String type,
        boolean sortable
) { }
