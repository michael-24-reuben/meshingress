package dev.mrk.meshingress.api.result.structured.tool;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class ToolListContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.TOOL_LIST;
    public static final String SCHEMA = StructuredContentSchemas.TOOL_LIST_V1;
    public static final int VERSION = 1;

    private List<ToolDescriptorContent> tools = new ArrayList<>();
    private Integer total;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public List<ToolDescriptorContent> getTools() { return tools; }
    public void setTools(List<ToolDescriptorContent> tools) { this.tools = tools == null ? new ArrayList<>() : new ArrayList<>(tools); }
    public Integer getTotal() { return total; }
    public void setTotal(Integer total) { this.total = total; }
}
