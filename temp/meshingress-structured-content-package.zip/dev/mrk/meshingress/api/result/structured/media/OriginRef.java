package dev.mrk.meshingress.api.result.structured.media;

public record OriginRef(
        String platform,
        String url,
        String externalId
) { }
