package dev.mrk.meshingress.api.result.structured.text;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class MarkdownContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.TEXT_MARKDOWN;
    public static final String SCHEMA = StructuredContentSchemas.TEXT_MARKDOWN_V1;
    public static final int VERSION = 1;

    private String title;
    private String markdown;
    private String language;

    public MarkdownContent() {}
    public MarkdownContent(String markdown) { this.markdown = markdown; }

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getMarkdown() { return markdown; }
    public void setMarkdown(String markdown) { this.markdown = markdown; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
}
