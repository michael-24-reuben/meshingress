package dev.mrk.meshingress.api.result.structured.web;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class WebPageContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.WEB_PAGE;
    public static final String SCHEMA = StructuredContentSchemas.WEB_PAGE_V1;
    public static final int VERSION = 1;

    private String url;
    private String finalUrl;
    private String title;
    private String description;
    private String html;
    private String text;
    private List<WebLinkContent> links = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getFinalUrl() { return finalUrl; }
    public void setFinalUrl(String finalUrl) { this.finalUrl = finalUrl; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getHtml() { return html; }
    public void setHtml(String html) { this.html = html; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public List<WebLinkContent> getLinks() { return links; }
    public void setLinks(List<WebLinkContent> links) { this.links = links == null ? new ArrayList<>() : new ArrayList<>(links); }
}
