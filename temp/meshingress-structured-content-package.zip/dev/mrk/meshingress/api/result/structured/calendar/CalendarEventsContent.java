package dev.mrk.meshingress.api.result.structured.calendar;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class CalendarEventsContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.CALENDAR_EVENTS;
    public static final String SCHEMA = StructuredContentSchemas.CALENDAR_EVENTS_V1;
    public static final int VERSION = 1;

    private String title;
    private String start;
    private String end;
    private String timezone;
    private List<CalendarEventContent> events = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getStart() { return start; }
    public void setStart(String start) { this.start = start; }
    public String getEnd() { return end; }
    public void setEnd(String end) { this.end = end; }
    public String getTimezone() { return timezone; }
    public void setTimezone(String timezone) { this.timezone = timezone; }
    public List<CalendarEventContent> getEvents() { return events; }
    public void setEvents(List<CalendarEventContent> events) { this.events = events == null ? new ArrayList<>() : new ArrayList<>(events); }
}
