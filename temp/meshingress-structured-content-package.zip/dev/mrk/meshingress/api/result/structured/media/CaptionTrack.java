package dev.mrk.meshingress.api.result.structured.media;

public record CaptionTrack(
        String language,
        String label,
        String url,
        String mimeType,
        String text
) { }
