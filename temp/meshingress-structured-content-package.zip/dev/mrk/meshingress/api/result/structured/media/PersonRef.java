package dev.mrk.meshingress.api.result.structured.media;

public record PersonRef(
        String id,
        String username,
        String displayName,
        String avatarUrl,
        String url
) { }
