package dev.mrk.meshingress.api.result.structured.media;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class GalleryContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MEDIA_GALLERY;
    public static final String SCHEMA = StructuredContentSchemas.MEDIA_GALLERY_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private List<MediaItemRef> items = new ArrayList<>();
    private OriginRef origin;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<MediaItemRef> getItems() { return items; }
    public void setItems(List<MediaItemRef> items) { this.items = items == null ? new ArrayList<>() : new ArrayList<>(items); }
    public OriginRef getOrigin() { return origin; }
    public void setOrigin(OriginRef origin) { this.origin = origin; }
}
