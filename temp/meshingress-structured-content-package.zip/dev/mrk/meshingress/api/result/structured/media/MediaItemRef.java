package dev.mrk.meshingress.api.result.structured.media;

public record MediaItemRef(
        String kind,
        String id,
        String title,
        String url,
        String mimeType,
        ImageRef thumbnail,
        Long durationMs
) { }
