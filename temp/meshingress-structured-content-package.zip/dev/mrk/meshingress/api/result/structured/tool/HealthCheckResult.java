package dev.mrk.meshingress.api.result.structured.tool;

public record HealthCheckResult(
        String name,
        String status,
        String message,
        Long durationMs
) { }
