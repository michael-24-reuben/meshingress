package dev.mrk.meshingress.api.result.structured.network;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

import java.util.LinkedHashMap;
import java.util.Map;

public final class HttpResponseContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.NETWORK_HTTP_RESPONSE;
    public static final String SCHEMA = StructuredContentSchemas.NETWORK_HTTP_RESPONSE_V1;
    public static final int VERSION = 1;

    private String url;
    private String method;
    private Integer status;
    private Map<String, String> headers = new LinkedHashMap<>();
    private JsonNode body;
    private Long durationMs;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public Map<String, String> getHeaders() { return headers; }
    public void setHeaders(Map<String, String> headers) { this.headers = headers == null ? new LinkedHashMap<>() : new LinkedHashMap<>(headers); }
    public JsonNode getBody() { return body; }
    public void setBody(JsonNode body) { this.body = body; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
}
