package dev.mrk.meshingress.api.result.structured.security;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

public final class AuditRecordContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.AUDIT_RECORD;
    public static final String SCHEMA = StructuredContentSchemas.AUDIT_RECORD_V1;
    public static final int VERSION = 1;

    private String id;
    private String timestamp;
    private String actor;
    private String action;
    private String target;
    private String outcome;
    private JsonNode details;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    public String getActor() { return actor; }
    public void setActor(String actor) { this.actor = actor; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getTarget() { return target; }
    public void setTarget(String target) { this.target = target; }
    public String getOutcome() { return outcome; }
    public void setOutcome(String outcome) { this.outcome = outcome; }
    public JsonNode getDetails() { return details; }
    public void setDetails(JsonNode details) { this.details = details; }
}
