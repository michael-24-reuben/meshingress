package dev.mrk.meshingress.api.result.structured.data;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

public final class RecordContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.DATA_RECORD;
    public static final String SCHEMA = StructuredContentSchemas.DATA_RECORD_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private JsonNode record;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public JsonNode getRecord() { return record; }
    public void setRecord(JsonNode record) { this.record = record; }
}
