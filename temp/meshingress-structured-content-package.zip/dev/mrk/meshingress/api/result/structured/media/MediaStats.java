package dev.mrk.meshingress.api.result.structured.media;

public record MediaStats(
        Long views,
        Long likes,
        Long comments,
        Long shares,
        Long saves
) { }
