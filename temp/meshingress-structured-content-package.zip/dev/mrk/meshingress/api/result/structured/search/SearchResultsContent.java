package dev.mrk.meshingress.api.result.structured.search;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class SearchResultsContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.SEARCH_RESULTS;
    public static final String SCHEMA = StructuredContentSchemas.SEARCH_RESULTS_V1;
    public static final int VERSION = 1;

    private String query;
    private List<SearchResult> results = new ArrayList<>();
    private Integer total;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }
    public List<SearchResult> getResults() { return results; }
    public void setResults(List<SearchResult> results) { this.results = results == null ? new ArrayList<>() : new ArrayList<>(results); }
    public Integer getTotal() { return total; }
    public void setTotal(Integer total) { this.total = total; }
}
