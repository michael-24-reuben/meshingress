package dev.mrk.meshingress.api.result.structured.data;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class TreeContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.DATA_TREE;
    public static final String SCHEMA = StructuredContentSchemas.DATA_TREE_V1;
    public static final int VERSION = 1;

    private String title;
    private TreeNode root;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public TreeNode getRoot() { return root; }
    public void setRoot(TreeNode root) { this.root = root; }
}
