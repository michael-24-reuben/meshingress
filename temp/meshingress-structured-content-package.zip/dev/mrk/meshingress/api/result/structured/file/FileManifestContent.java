package dev.mrk.meshingress.api.result.structured.file;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class FileManifestContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.FILE_MANIFEST;
    public static final String SCHEMA = StructuredContentSchemas.FILE_MANIFEST_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String basePath;
    private List<FileEntry> files = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getBasePath() { return basePath; }
    public void setBasePath(String basePath) { this.basePath = basePath; }
    public List<FileEntry> getFiles() { return files; }
    public void setFiles(List<FileEntry> files) { this.files = files == null ? new ArrayList<>() : new ArrayList<>(files); }
}
