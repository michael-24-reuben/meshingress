package dev.mrk.meshingress.api.result.structured.data;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

public final class TableContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.DATA_TABLE;
    public static final String SCHEMA = StructuredContentSchemas.DATA_TABLE_V1;
    public static final int VERSION = 1;

    private String title;
    private List<TableColumn> columns = new ArrayList<>();
    private List<JsonNode> rows = new ArrayList<>();
    private Integer total;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public List<TableColumn> getColumns() { return columns; }
    public void setColumns(List<TableColumn> columns) { this.columns = columns == null ? new ArrayList<>() : new ArrayList<>(columns); }
    public List<JsonNode> getRows() { return rows; }
    public void setRows(List<JsonNode> rows) { this.rows = rows == null ? new ArrayList<>() : new ArrayList<>(rows); }
    public Integer getTotal() { return total; }
    public void setTotal(Integer total) { this.total = total; }
}
