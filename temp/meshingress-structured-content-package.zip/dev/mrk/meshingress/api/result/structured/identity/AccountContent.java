package dev.mrk.meshingress.api.result.structured.identity;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class AccountContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.IDENTITY_ACCOUNT;
    public static final String SCHEMA = StructuredContentSchemas.IDENTITY_ACCOUNT_V1;
    public static final int VERSION = 1;

    private String id;
    private String provider;
    private String username;
    private String displayName;
    private String avatarUrl;
    private String url;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}
