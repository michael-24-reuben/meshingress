package dev.mrk.meshingress.api.result.structured.process;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class ProcessExecutionContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.PROCESS_EXECUTION;
    public static final String SCHEMA = StructuredContentSchemas.PROCESS_EXECUTION_V1;
    public static final int VERSION = 1;

    private String command;
    private List<String> args = new ArrayList<>();
    private String workingDirectory;
    private Integer exitCode;
    private String stdout;
    private String stderr;
    private boolean timedOut;
    private Long durationMs;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getCommand() { return command; }
    public void setCommand(String command) { this.command = command; }
    public List<String> getArgs() { return args; }
    public void setArgs(List<String> args) { this.args = args == null ? new ArrayList<>() : new ArrayList<>(args); }
    public String getWorkingDirectory() { return workingDirectory; }
    public void setWorkingDirectory(String workingDirectory) { this.workingDirectory = workingDirectory; }
    public Integer getExitCode() { return exitCode; }
    public void setExitCode(Integer exitCode) { this.exitCode = exitCode; }
    public String getStdout() { return stdout; }
    public void setStdout(String stdout) { this.stdout = stdout; }
    public String getStderr() { return stderr; }
    public void setStderr(String stderr) { this.stderr = stderr; }
    public boolean isTimedOut() { return timedOut; }
    public void setTimedOut(boolean timedOut) { this.timedOut = timedOut; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
}
