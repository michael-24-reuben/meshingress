package dev.mrk.meshingress.api.result.structured.file;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class DirectoryContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.FILE_DIRECTORY;
    public static final String SCHEMA = StructuredContentSchemas.FILE_DIRECTORY_V1;
    public static final int VERSION = 1;

    private String name;
    private String path;
    private String url;
    private List<FileEntry> entries = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public List<FileEntry> getEntries() { return entries; }
    public void setEntries(List<FileEntry> entries) { this.entries = entries == null ? new ArrayList<>() : new ArrayList<>(entries); }
}
