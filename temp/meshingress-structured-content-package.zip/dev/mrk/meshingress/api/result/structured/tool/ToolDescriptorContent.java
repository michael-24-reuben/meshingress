package dev.mrk.meshingress.api.result.structured.tool;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

public final class ToolDescriptorContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.TOOL_DESCRIPTOR;
    public static final String SCHEMA = StructuredContentSchemas.TOOL_DESCRIPTOR_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private String defaultFunction;
    private List<String> scopes = new ArrayList<>();
    private JsonNode inputSchema;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDefaultFunction() { return defaultFunction; }
    public void setDefaultFunction(String defaultFunction) { this.defaultFunction = defaultFunction; }
    public List<String> getScopes() { return scopes; }
    public void setScopes(List<String> scopes) { this.scopes = scopes == null ? new ArrayList<>() : new ArrayList<>(scopes); }
    public JsonNode getInputSchema() { return inputSchema; }
    public void setInputSchema(JsonNode inputSchema) { this.inputSchema = inputSchema; }
}
