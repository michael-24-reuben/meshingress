package dev.mrk.meshingress.api.result.structured.process;

public record DiagnosticIssue(
        String severity,
        String code,
        String message,
        String path,
        String hint
) { }
