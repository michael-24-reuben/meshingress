package dev.mrk.meshingress.api.result.structured.text;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class TextHtmlContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.TEXT_HTML;
    public static final String SCHEMA = StructuredContentSchemas.TEXT_HTML_V1;
    public static final int VERSION = 1;

    private String title;
    private String html;
    private String text;
    private boolean sanitized;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getHtml() { return html; }
    public void setHtml(String html) { this.html = html; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public boolean isSanitized() { return sanitized; }
    public void setSanitized(boolean sanitized) { this.sanitized = sanitized; }
}
