package dev.mrk.meshingress.api.result.structured.process;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class DiagnosticContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.PROCESS_DIAGNOSTIC;
    public static final String SCHEMA = StructuredContentSchemas.PROCESS_DIAGNOSTIC_V1;
    public static final int VERSION = 1;

    private String status;
    private String summary;
    private List<DiagnosticIssue> issues = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public List<DiagnosticIssue> getIssues() { return issues; }
    public void setIssues(List<DiagnosticIssue> issues) { this.issues = issues == null ? new ArrayList<>() : new ArrayList<>(issues); }
}
