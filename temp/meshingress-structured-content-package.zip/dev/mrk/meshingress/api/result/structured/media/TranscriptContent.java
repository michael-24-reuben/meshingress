package dev.mrk.meshingress.api.result.structured.media;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class TranscriptContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MEDIA_TRANSCRIPT;
    public static final String SCHEMA = StructuredContentSchemas.MEDIA_TRANSCRIPT_V1;
    public static final int VERSION = 1;

    private String language;
    private String text;
    private List<TranscriptSegment> segments = new ArrayList<>();
    private OriginRef origin;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public List<TranscriptSegment> getSegments() { return segments; }
    public void setSegments(List<TranscriptSegment> segments) { this.segments = segments == null ? new ArrayList<>() : new ArrayList<>(segments); }
    public OriginRef getOrigin() { return origin; }
    public void setOrigin(OriginRef origin) { this.origin = origin; }
}
