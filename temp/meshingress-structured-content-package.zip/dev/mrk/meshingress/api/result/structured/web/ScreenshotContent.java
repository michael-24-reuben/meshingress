package dev.mrk.meshingress.api.result.structured.web;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class ScreenshotContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.WEB_SCREENSHOT;
    public static final String SCHEMA = StructuredContentSchemas.WEB_SCREENSHOT_V1;
    public static final int VERSION = 1;

    private String url;
    private String imageUrl;
    private String path;
    private String mimeType;
    private Integer width;
    private Integer height;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }
    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }
    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }
}
