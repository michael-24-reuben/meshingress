package dev.mrk.meshingress.api.result.structured.security;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class SecurityDecisionContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.SECURITY_DECISION;
    public static final String SCHEMA = StructuredContentSchemas.SECURITY_DECISION_V1;
    public static final int VERSION = 1;

    private String decision;
    private String reason;
    private List<String> scopes = new ArrayList<>();
    private String riskLevel;
    private boolean requiresApproval;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public List<String> getScopes() { return scopes; }
    public void setScopes(List<String> scopes) { this.scopes = scopes == null ? new ArrayList<>() : new ArrayList<>(scopes); }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public boolean isRequiresApproval() { return requiresApproval; }
    public void setRequiresApproval(boolean requiresApproval) { this.requiresApproval = requiresApproval; }
}
