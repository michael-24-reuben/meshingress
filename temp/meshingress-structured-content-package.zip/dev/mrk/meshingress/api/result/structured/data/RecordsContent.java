package dev.mrk.meshingress.api.result.structured.data;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;
import tools.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

public final class RecordsContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.DATA_RECORDS;
    public static final String SCHEMA = StructuredContentSchemas.DATA_RECORDS_V1;
    public static final int VERSION = 1;

    private String title;
    private List<JsonNode> records = new ArrayList<>();
    private Integer total;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public List<JsonNode> getRecords() { return records; }
    public void setRecords(List<JsonNode> records) { this.records = records == null ? new ArrayList<>() : new ArrayList<>(records); }
    public Integer getTotal() { return total; }
    public void setTotal(Integer total) { this.total = total; }
}
