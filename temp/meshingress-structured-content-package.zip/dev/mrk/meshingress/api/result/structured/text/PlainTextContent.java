package dev.mrk.meshingress.api.result.structured.text;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class PlainTextContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.TEXT_PLAIN;
    public static final String SCHEMA = StructuredContentSchemas.TEXT_PLAIN_V1;
    public static final int VERSION = 1;

    private String title;
    private String text;
    private String language;

    public PlainTextContent() {}
    public PlainTextContent(String text) { this.text = text; }

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
}
