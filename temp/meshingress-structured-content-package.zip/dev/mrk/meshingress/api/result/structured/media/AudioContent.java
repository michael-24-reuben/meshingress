package dev.mrk.meshingress.api.result.structured.media;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class AudioContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MEDIA_AUDIO;
    public static final String SCHEMA = StructuredContentSchemas.MEDIA_AUDIO_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private Long durationMs;
    private List<MediaSource> sources = new ArrayList<>();
    private ImageRef artwork;
    private PersonRef author;
    private OriginRef origin;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
    public List<MediaSource> getSources() { return sources; }
    public void setSources(List<MediaSource> sources) { this.sources = sources == null ? new ArrayList<>() : new ArrayList<>(sources); }
    public ImageRef getArtwork() { return artwork; }
    public void setArtwork(ImageRef artwork) { this.artwork = artwork; }
    public PersonRef getAuthor() { return author; }
    public void setAuthor(PersonRef author) { this.author = author; }
    public OriginRef getOrigin() { return origin; }
    public void setOrigin(OriginRef origin) { this.origin = origin; }
}
