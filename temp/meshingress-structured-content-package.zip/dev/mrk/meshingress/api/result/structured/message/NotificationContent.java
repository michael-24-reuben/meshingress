package dev.mrk.meshingress.api.result.structured.message;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class NotificationContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MESSAGE_NOTIFICATION;
    public static final String SCHEMA = StructuredContentSchemas.MESSAGE_NOTIFICATION_V1;
    public static final int VERSION = 1;

    private String title;
    private String body;
    private String severity;
    private List<NotificationAction> actions = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }
    public List<NotificationAction> getActions() { return actions; }
    public void setActions(List<NotificationAction> actions) { this.actions = actions == null ? new ArrayList<>() : new ArrayList<>(actions); }
}
