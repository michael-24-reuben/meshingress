package dev.mrk.meshingress.api.result.structured;

import tools.jackson.databind.node.ObjectNode;

import java.util.Optional;

/**
 * Base type for schema-bound structured tool output.
 * <p>
 * Implementations represent stable frontend-consumable content kinds such as
 * media.video, file.archive, process.execution, or web.page. The common wire
 * shape is produced by {@link StructuredContentMapper}:
 *
 * <pre>
 * {
 *   "kind": "media.video",
 *   "schema": "meshingress.media.video.v1",
 *   "version": 1,
 *   "data": { ... },
 *   "extra": { ... }
 * }
 * </pre>
 *
 * {@code extra} is reserved for source/tool/vendor-specific data. It must not
 * override or replace standard fields in the formal schema.
 */
public abstract class StructuredContent {

    private ObjectNode extra;

    public abstract String kind();

    public abstract String schema();

    public abstract int version();

    public final Optional<ObjectNode> extra() {
        return Optional.ofNullable(extra);
    }

    public final ObjectNode extraOrNull() {
        return extra;
    }

    public final StructuredContent extra(ObjectNode extra) {
        this.extra = extra;
        return this;
    }

    public final StructuredContent clearExtra() {
        this.extra = null;
        return this;
    }
}
