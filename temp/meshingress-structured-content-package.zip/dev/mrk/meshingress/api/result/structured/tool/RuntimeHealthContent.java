package dev.mrk.meshingress.api.result.structured.tool;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class RuntimeHealthContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.RUNTIME_HEALTH;
    public static final String SCHEMA = StructuredContentSchemas.RUNTIME_HEALTH_V1;
    public static final int VERSION = 1;

    private String status;
    private Long uptimeMs;
    private List<HealthCheckResult> checks = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Long getUptimeMs() { return uptimeMs; }
    public void setUptimeMs(Long uptimeMs) { this.uptimeMs = uptimeMs; }
    public List<HealthCheckResult> getChecks() { return checks; }
    public void setChecks(List<HealthCheckResult> checks) { this.checks = checks == null ? new ArrayList<>() : new ArrayList<>(checks); }
}
