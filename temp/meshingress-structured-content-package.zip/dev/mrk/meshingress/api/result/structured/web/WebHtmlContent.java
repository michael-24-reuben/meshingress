package dev.mrk.meshingress.api.result.structured.web;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

public final class WebHtmlContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.WEB_HTML;
    public static final String SCHEMA = StructuredContentSchemas.WEB_HTML_V1;
    public static final int VERSION = 1;

    private String url;
    private String html;
    private String text;
    private boolean sanitized;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getHtml() { return html; }
    public void setHtml(String html) { this.html = html; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public boolean isSanitized() { return sanitized; }
    public void setSanitized(boolean sanitized) { this.sanitized = sanitized; }
}
