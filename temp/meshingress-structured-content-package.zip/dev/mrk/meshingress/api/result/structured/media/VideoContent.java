package dev.mrk.meshingress.api.result.structured.media;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class VideoContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MEDIA_VIDEO;
    public static final String SCHEMA = StructuredContentSchemas.MEDIA_VIDEO_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private Long durationMs;
    private Integer width;
    private Integer height;
    private List<MediaSource> sources = new ArrayList<>();
    private ImageRef poster;
    private List<ImageRef> thumbnails = new ArrayList<>();
    private List<CaptionTrack> captions = new ArrayList<>();
    private PersonRef author;
    private OriginRef origin;
    private MediaStats stats;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }
    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }
    public List<MediaSource> getSources() { return sources; }
    public void setSources(List<MediaSource> sources) { this.sources = sources == null ? new ArrayList<>() : new ArrayList<>(sources); }
    public ImageRef getPoster() { return poster; }
    public void setPoster(ImageRef poster) { this.poster = poster; }
    public List<ImageRef> getThumbnails() { return thumbnails; }
    public void setThumbnails(List<ImageRef> thumbnails) { this.thumbnails = thumbnails == null ? new ArrayList<>() : new ArrayList<>(thumbnails); }
    public List<CaptionTrack> getCaptions() { return captions; }
    public void setCaptions(List<CaptionTrack> captions) { this.captions = captions == null ? new ArrayList<>() : new ArrayList<>(captions); }
    public PersonRef getAuthor() { return author; }
    public void setAuthor(PersonRef author) { this.author = author; }
    public OriginRef getOrigin() { return origin; }
    public void setOrigin(OriginRef origin) { this.origin = origin; }
    public MediaStats getStats() { return stats; }
    public void setStats(MediaStats stats) { this.stats = stats; }
}
