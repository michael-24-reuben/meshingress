package dev.mrk.meshingress.api.result.structured.media;

public record TranscriptSegment(
        Long startMs,
        Long endMs,
        String speaker,
        String text
) { }
