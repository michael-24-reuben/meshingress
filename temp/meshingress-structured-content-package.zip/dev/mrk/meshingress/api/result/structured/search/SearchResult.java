package dev.mrk.meshingress.api.result.structured.search;

import tools.jackson.databind.JsonNode;

public record SearchResult(
        String id,
        String title,
        String summary,
        Double score,
        SourceRef source,
        JsonNode payload
) { }
