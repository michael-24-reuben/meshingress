package dev.mrk.meshingress.api.result.structured.calendar;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class CalendarEventContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.CALENDAR_EVENT;
    public static final String SCHEMA = StructuredContentSchemas.CALENDAR_EVENT_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private String start;
    private String end;
    private String timezone;
    private String location;
    private List<String> attendees = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getStart() { return start; }
    public void setStart(String start) { this.start = start; }
    public String getEnd() { return end; }
    public void setEnd(String end) { this.end = end; }
    public String getTimezone() { return timezone; }
    public void setTimezone(String timezone) { this.timezone = timezone; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public List<String> getAttendees() { return attendees; }
    public void setAttendees(List<String> attendees) { this.attendees = attendees == null ? new ArrayList<>() : new ArrayList<>(attendees); }
}
