package dev.mrk.meshingress.api.result.structured.web;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.LinkedHashMap;
import java.util.Map;

public final class WebElementContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.WEB_ELEMENT;
    public static final String SCHEMA = StructuredContentSchemas.WEB_ELEMENT_V1;
    public static final int VERSION = 1;

    private String tagName;
    private String text;
    private String selector;
    private String xpath;
    private Map<String, String> attributes = new LinkedHashMap<>();
    private Double score;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTagName() { return tagName; }
    public void setTagName(String tagName) { this.tagName = tagName; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public String getSelector() { return selector; }
    public void setSelector(String selector) { this.selector = selector; }
    public String getXpath() { return xpath; }
    public void setXpath(String xpath) { this.xpath = xpath; }
    public Map<String, String> getAttributes() { return attributes; }
    public void setAttributes(Map<String, String> attributes) { this.attributes = attributes == null ? new LinkedHashMap<>() : new LinkedHashMap<>(attributes); }
    public Double getScore() { return score; }
    public void setScore(Double score) { this.score = score; }
}
