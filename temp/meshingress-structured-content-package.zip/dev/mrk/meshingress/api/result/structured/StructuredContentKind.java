package dev.mrk.meshingress.api.result.structured;

public final class StructuredContentKind {
    private StructuredContentKind() {}

    public static final String TEXT_PLAIN = "text.plain";
    public static final String TEXT_MARKDOWN = "text.markdown";
    public static final String TEXT_HTML = "text.html";

    public static final String MEDIA_VIDEO = "media.video";
    public static final String MEDIA_IMAGE = "media.image";
    public static final String MEDIA_AUDIO = "media.audio";
    public static final String MEDIA_GALLERY = "media.gallery";
    public static final String MEDIA_PLAYLIST = "media.playlist";
    public static final String MEDIA_TRANSCRIPT = "media.transcript";

    public static final String FILE_GENERIC = "file.generic";
    public static final String FILE_ARCHIVE = "file.archive";
    public static final String FILE_DIRECTORY = "file.directory";
    public static final String FILE_MANIFEST = "file.manifest";

    public static final String WEB_PAGE = "web.page";
    public static final String WEB_HTML = "web.html";
    public static final String WEB_LINK = "web.link";
    public static final String WEB_SCREENSHOT = "web.screenshot";
    public static final String WEB_ELEMENT = "web.element";

    public static final String PROCESS_EXECUTION = "process.execution";
    public static final String PROCESS_DIAGNOSTIC = "process.diagnostic";

    public static final String DATA_RECORD = "data.record";
    public static final String DATA_RECORDS = "data.records";
    public static final String DATA_TABLE = "data.table";
    public static final String DATA_TREE = "data.tree";
    public static final String DATA_TIMELINE = "data.timeline";

    public static final String SEARCH_RESULTS = "search.results";
    public static final String RETRIEVAL_CONTEXT = "retrieval.context";

    public static final String MESSAGE_NOTIFICATION = "message.notification";

    public static final String IDENTITY_USER = "identity.user";
    public static final String IDENTITY_ACCOUNT = "identity.account";

    public static final String TOOL_DESCRIPTOR = "tool.descriptor";
    public static final String TOOL_LIST = "tool.list";
    public static final String RUNTIME_HEALTH = "runtime.health";

    public static final String SECURITY_DECISION = "security.decision";
    public static final String AUDIT_RECORD = "audit.record";

    public static final String CALENDAR_EVENT = "calendar.event";
    public static final String CALENDAR_EVENTS = "calendar.events";

    public static final String NETWORK_HTTP_RESPONSE = "network.http.response";
}
