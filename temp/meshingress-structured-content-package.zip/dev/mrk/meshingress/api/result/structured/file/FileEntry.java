package dev.mrk.meshingress.api.result.structured.file;

public record FileEntry(
        String name,
        String path,
        String type,
        String mimeType,
        Long sizeBytes,
        String checksum,
        String checksumAlgorithm
) { }
