package dev.mrk.meshingress.api.result.structured.search;

public record SourceRef(
        String type,
        String id,
        String path,
        String url,
        String title
) { }
