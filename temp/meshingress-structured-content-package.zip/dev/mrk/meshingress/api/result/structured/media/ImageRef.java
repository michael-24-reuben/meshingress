package dev.mrk.meshingress.api.result.structured.media;

public record ImageRef(
        String url,
        String mimeType,
        Integer width,
        Integer height,
        String alt
) { }
