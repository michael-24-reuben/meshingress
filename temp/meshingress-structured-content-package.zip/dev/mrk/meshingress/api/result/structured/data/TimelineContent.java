package dev.mrk.meshingress.api.result.structured.data;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class TimelineContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.DATA_TIMELINE;
    public static final String SCHEMA = StructuredContentSchemas.DATA_TIMELINE_V1;
    public static final int VERSION = 1;

    private String title;
    private List<TimelineEvent> events = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public List<TimelineEvent> getEvents() { return events; }
    public void setEvents(List<TimelineEvent> events) { this.events = events == null ? new ArrayList<>() : new ArrayList<>(events); }
}
