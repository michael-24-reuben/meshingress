package dev.mrk.meshingress.api.result.structured.media;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class ImageContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.MEDIA_IMAGE;
    public static final String SCHEMA = StructuredContentSchemas.MEDIA_IMAGE_V1;
    public static final int VERSION = 1;

    private String id;
    private String title;
    private String description;
    private String url;
    private String mimeType;
    private Integer width;
    private Integer height;
    private String alt;
    private List<ImageRef> variants = new ArrayList<>();
    private PersonRef author;
    private OriginRef origin;

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }
    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }
    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }
    public String getAlt() { return alt; }
    public void setAlt(String alt) { this.alt = alt; }
    public List<ImageRef> getVariants() { return variants; }
    public void setVariants(List<ImageRef> variants) { this.variants = variants == null ? new ArrayList<>() : new ArrayList<>(variants); }
    public PersonRef getAuthor() { return author; }
    public void setAuthor(PersonRef author) { this.author = author; }
    public OriginRef getOrigin() { return origin; }
    public void setOrigin(OriginRef origin) { this.origin = origin; }
}
