package dev.mrk.meshingress.api.result.structured.message;

public record NotificationAction(
        String label,
        String url,
        String action,
        String style
) { }
