package dev.mrk.meshingress.api.result.structured.search;

import dev.mrk.meshingress.api.result.structured.StructuredContent;
import dev.mrk.meshingress.api.result.structured.StructuredContentKind;
import dev.mrk.meshingress.api.result.structured.StructuredContentSchemas;

import java.util.ArrayList;
import java.util.List;

public final class RetrievalContextContent extends StructuredContent {
    public static final String KIND = StructuredContentKind.RETRIEVAL_CONTEXT;
    public static final String SCHEMA = StructuredContentSchemas.RETRIEVAL_CONTEXT_V1;
    public static final int VERSION = 1;

    private String query;
    private String answer;
    private List<SearchResult> contexts = new ArrayList<>();

    @Override public String kind() { return KIND; }
    @Override public String schema() { return SCHEMA; }
    @Override public int version() { return VERSION; }

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }
    public String getAnswer() { return answer; }
    public void setAnswer(String answer) { this.answer = answer; }
    public List<SearchResult> getContexts() { return contexts; }
    public void setContexts(List<SearchResult> contexts) { this.contexts = contexts == null ? new ArrayList<>() : new ArrayList<>(contexts); }
}
