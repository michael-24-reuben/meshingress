package dev.mrk.meshingress.api.result.structured;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.node.ObjectNode;

/** Immutable view of the structuredContent wire envelope. */
public record StructuredContentEnvelope(
        String kind,
        String schema,
        int version,
        JsonNode data,
        ObjectNode extra
) { }
