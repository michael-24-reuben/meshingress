# Verification Plan

## Unit Tests

Add tests for `McpRouteValidator` covering:

- valid `@EnableWithinTimeRanges` produces no violations,
- blank `zone` produces a violation,
- invalid `zone` produces a violation,
- blank range produces a violation,
- malformed range produces a violation,
- range with unparsable `LocalTime` produces a violation,
- range where start is not before end produces a violation,
- blank feature flag name produces a violation,
- availability annotation with no registered runtime policy produces a violation,
- availability annotation with no `@RouteAvailabilityCondition` produces a violation,
- declared condition class missing from Spring context produces a violation,
- multiple invalid routes return multiple violations collectively.

## Integration Check

Start the Spring context with built-in availability annotations and confirm:

- `WithinTimeRangesCondition` is discoverable as a Spring bean,
- `FeatureFlagOnCondition` is discoverable as a Spring bean,
- `McpRouteValidator` can resolve both through `ApplicationContext.getBean(...)`,
- application startup reports route metadata errors collectively.

## Regression Checks

Confirm existing validation remains unchanged for:

- duplicate route IDs,
- blank route IDs,
- route paths not beginning with `/`,
- invalid handler method signatures,
- invalid timeout values,
- blank secret names,
- blank secret refs.
