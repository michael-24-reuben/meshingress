# Context

## Current validator behavior

`McpRouteValidator` currently aggregates route validation failures into a `List<String>`. It validates route identity, route path, handler signature, route configuration, and availability annotations.

The current availability validation path performs direct concrete checks similar to:

```java
if (annotation instanceof EnableWithinTimeRanges timeRanges) {
    ZoneId.of(timeRanges.zone());
    for (String range : timeRanges.ranges()) {
        validateTimeRange(route, range, violations);
    }
}

if (annotation instanceof EnableWhenFeatureFlagOn featureFlag && featureFlag.value().isBlank()) {
    violations.add(location(route) + " has a blank feature flag name");
}
```

This makes the central validator responsible for knowing every availability annotation's internal rules.

## Desired behavior

Each availability annotation should declare the validation/condition class that owns its metadata checks:

```java
@RouteAvailabilityCondition(WithinTimeRangesCondition.class)
public @interface EnableWithinTimeRanges {
    String zone();
    String[] ranges();
}
```

`McpRouteValidator` should become an orchestrator:

1. It finds availability annotations attached to a route.
2. It verifies that a runtime policy exists for the annotation type.
3. It reads the annotation's `@RouteAvailabilityCondition` declaration.
4. It pulls the declared class from Spring.
5. It invokes the common validation method.
6. It aggregates returned violations.

## Design rationale

This keeps annotation-specific validation near the annotation/policy implementation and avoids a growing block of `instanceof` checks inside `McpRouteValidator`.

It also supports third-party or module-provided availability annotations as long as they:

- register an availability policy,
- declare `@RouteAvailabilityCondition(...)`, and
- expose the condition class as a Spring bean.

## Error aggregation principle

Normal validation failures should be returned as strings and aggregated. The route validator should output all discovered violations collectively so developers can fix multiple route metadata issues in one pass.

Infrastructure failures, such as a missing Spring bean for a declared condition class, should also be converted into validation messages rather than crashing early with an opaque exception.

## Runtime availability policy separation

This entry does not require removing `AvailabilityPolicyRegistry`. The policy registry still answers whether an availability annotation has runtime behavior. The new condition class answers whether the annotation metadata is well-formed.

Future work may decide whether a single class should both validate and evaluate runtime availability, but that is intentionally out of scope for this entry.
