# Brief

## Problem

`McpRouteValidator` currently validates built-in availability annotations through direct type checks, such as checking whether an annotation is an `EnableWithinTimeRanges` or `EnableWhenFeatureFlagOn`. This couples route validation to every concrete availability annotation type and forces validator changes whenever a new availability annotation is added.

## Goal

Introduce annotation-declared availability validation so each availability annotation identifies the Spring-managed validator/condition class responsible for validating its metadata.

Target usage:

```java
@RouteAvailabilityCondition(WithinTimeRangesCondition.class)
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface EnableWithinTimeRanges {

    String zone();

    String[] ranges();
}
```

The route validator should inspect each availability annotation type, read its `@RouteAvailabilityCondition(...)` declaration, resolve that class from the Spring context, invoke its common validation method, and aggregate any returned violations.

## Required Class Change

In module:

```txt
lib/meshingress-route-framework
```

Class:

```txt
McpRouteValidator
```

Replace the current logic of:

```java
public List<String> validate(List<AnnotatedMcpRoute> routes)
```

and its availability-validation path so validation is driven by annotation-based class reflection/resolution:

1. For each route, inspect `route.availabilityAnnotations()`.
2. For each availability annotation, read `@RouteAvailabilityCondition` from `annotation.annotationType()`.
3. Pull the referenced validation/condition class from Spring.
4. Invoke its common method.
5. Collect returned errors into the validator's shared `violations` list.
6. Return all violations collectively.

## Non-Goal

This change is for startup/configuration validation of annotation metadata. Runtime route availability evaluation may continue using the existing availability policy registry unless a later architecture entry explicitly merges validation and runtime condition evaluation.
