# Todo

- [ ] Locate `McpRouteValidator` in `lib/meshingress-route-framework`.
- [ ] Add `@RouteAvailabilityCondition` meta-annotation.
- [ ] Add `AvailabilityCondition<A extends Annotation>` interface.
- [ ] Add `AvailabilityValidationContext` record.
- [ ] Implement `WithinTimeRangesCondition` as a Spring bean.
- [ ] Implement `FeatureFlagOnCondition` as a Spring bean.
- [ ] Annotate `EnableWithinTimeRanges` with `@RouteAvailabilityCondition(WithinTimeRangesCondition.class)`.
- [ ] Annotate `EnableWhenFeatureFlagOn` with `@RouteAvailabilityCondition(FeatureFlagOnCondition.class)`.
- [ ] Refactor `McpRouteValidator.validateAvailability(...)` to read the condition class from each annotation type.
- [ ] Resolve condition classes from Spring using `ApplicationContext.getBean(conditionType)`.
- [ ] Aggregate condition validation errors into the existing shared violations list.
- [ ] Preserve existing duplicate route ID, path, handler signature, and configuration validation behavior.
- [ ] Add tests for invalid zone, invalid range format, blank feature flag, missing condition annotation, and missing Spring bean.
- [ ] Add tests confirming multiple availability validation errors are returned collectively.
