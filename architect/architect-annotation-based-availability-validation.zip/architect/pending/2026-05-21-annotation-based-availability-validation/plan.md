# Plan

## 1. Add meta-annotation for availability validators

Create an annotation that can be applied to availability annotation types only:

```java
@Target(ElementType.ANNOTATION_TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface RouteAvailabilityCondition {

    Class<? extends AvailabilityCondition<? extends Annotation>> value();
}
```

The `ANNOTATION_TYPE` target is required because this annotation belongs on declarations such as `public @interface EnableWithinTimeRanges`, not on route handler methods directly.

## 2. Add common validation interface

Create a common interface implemented by every availability condition/validator class:

```java
public interface AvailabilityCondition<A extends Annotation> {

    List<String> validate(A annotation, AvailabilityValidationContext context);
}
```

The method returns violations instead of throwing for normal validation failures. Exceptions should be reserved for unexpected validator infrastructure failures.

## 3. Add validation context record

Create a context object so condition classes can generate useful route-aware messages without depending on the full `AnnotatedMcpRoute` type:

```java
public record AvailabilityValidationContext(
        Class<?> controllerType,
        Method handlerMethod
) {
    public String location() {
        return controllerType.getName() + "#" + handlerMethod.getName();
    }
}
```

## 4. Implement `WithinTimeRangesCondition`

Create a Spring bean implementing:

```java
@Component
public final class WithinTimeRangesCondition
        implements AvailabilityCondition<EnableWithinTimeRanges> {

    @Override
    public List<String> validate(
            EnableWithinTimeRanges annotation,
            AvailabilityValidationContext context
    ) {
        // Validate zone with ZoneId.of(annotation.zone()).
        // Validate ranges with LocalTime.parse(start/end).
        // Collect all violations.
    }
}
```

Validation rules:

- `zone` must not be blank.
- `zone` must parse through `ZoneId.of(...)`.
- `ranges` must not be empty.
- Each range must not be blank.
- Each range must split into exactly two parts by the first `-`.
- Both parts must parse through `LocalTime.parse(...)`.
- Start should be before end unless overnight windows are explicitly supported later.

## 5. Implement feature-flag condition

Create a Spring bean implementing:

```java
@Component
public final class FeatureFlagOnCondition
        implements AvailabilityCondition<EnableWhenFeatureFlagOn> {

    @Override
    public List<String> validate(
            EnableWhenFeatureFlagOn annotation,
            AvailabilityValidationContext context
    ) {
        // Validate nonblank feature flag name.
    }
}
```

## 6. Annotate availability annotations

Update built-in availability annotation declarations:

```java
@RouteAvailabilityCondition(WithinTimeRangesCondition.class)
public @interface EnableWithinTimeRanges {
    String zone();
    String[] ranges();
}
```

```java
@RouteAvailabilityCondition(FeatureFlagOnCondition.class)
public @interface EnableWhenFeatureFlagOn {
    String value();
}
```

## 7. Refactor `McpRouteValidator`

In `lib/meshingress-route-framework`, update `class McpRouteValidator` so the availability validation path no longer hardcodes built-in annotation types.

Expected flow:

```java
private void validateAvailability(
        AnnotatedMcpRoute route,
        List<String> violations
) {
    AvailabilityValidationContext context = new AvailabilityValidationContext(
            route.controllerType(),
            route.handlerMethod()
    );

    for (Annotation annotation : route.availabilityAnnotations()) {
        Class<? extends Annotation> annotationType = annotation.annotationType();

        if (availabilityPolicyRegistry.findPolicy(annotationType).isEmpty()) {
            violations.add(context.location()
                    + " has no policy for availability annotation "
                    + annotationType.getName());
            continue;
        }

        RouteAvailabilityCondition conditionDeclaration =
                annotationType.getAnnotation(RouteAvailabilityCondition.class);

        if (conditionDeclaration == null) {
            violations.add(context.location()
                    + " availability annotation is missing @RouteAvailabilityCondition: "
                    + annotationType.getName());
            continue;
        }

        validateWithCondition(
                conditionDeclaration.value(),
                annotation,
                context,
                violations
        );
    }
}
```

Spring-based resolution:

```java
@SuppressWarnings("unchecked")
private <A extends Annotation> void validateWithCondition(
        Class<? extends AvailabilityCondition<? extends Annotation>> conditionType,
        Annotation annotation,
        AvailabilityValidationContext context,
        List<String> violations
) {
    try {
        AvailabilityCondition<A> condition =
                (AvailabilityCondition<A>) applicationContext.getBean(conditionType);

        A typedAnnotation = (A) annotation;

        violations.addAll(condition.validate(typedAnnotation, context));
    } catch (NoSuchBeanDefinitionException exception) {
        violations.add(context.location()
                + " availability condition is not registered as a Spring bean: "
                + conditionType.getName());
    } catch (RuntimeException exception) {
        violations.add(context.location()
                + " availability condition failed: "
                + conditionType.getName()
                + ": "
                + exception.getMessage());
    }
}
```

## 8. Preserve collective error output

`public List<String> validate(List<AnnotatedMcpRoute> routes)` should keep returning a copied list of all route validation failures:

```java
public List<String> validate(List<AnnotatedMcpRoute> routes) {
    List<String> violations = new ArrayList<>();
    Set<String> routeIds = new HashSet<>();

    for (AnnotatedMcpRoute route : routes) {
        validateRoute(route, routeIds, violations);
    }

    return List.copyOf(violations);
}
```

Only the availability-specific validation internals should be replaced with the annotation-based condition lookup and invocation.
